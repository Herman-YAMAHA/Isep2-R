# ===============================
# SCRIPT GLOBAL - EHCVM 2018-2019
# Auteur : NGAKE YAMAHA Herman Parfait
# Projet : Impact des transferts sur le bien-être des ménages
# ===============================


# ------------------------------------------------------------------
# SCRIPT 01 : Traitement des données éducatives - EHCVM 2018-2019
# ------------------------------------------------------------------


# Installation des packages nécessaires

install.packages("haven")
install.packages("tidyr")


# Chargement des packages nécessaires

library(haven)
library(dplyr)

# Définir le répertoire de travail

# Adapter ce chemin d'accès à votre propre ordinateur pour que le code fonctionne correctement

setwd("C:/Users/T Informatique/Desktop/Projet _ EHCVM 2018-2019 _ Thème 10 _ Herman YAMAHA")

# ------------------------------------------------------------------
# 1. Chargement des données
# ------------------------------------------------------------------

data1 <- read_dta("Bases de données/s02_me_SEN2018.dta")

# ------------------------------------------------------------------
# 2. Imputation des variables éducatives
# ------------------------------------------------------------------

# Variable s02q03 - École formelle

data1$s02q03 <- as.character(data1$s02q03)

data1 <- data1 %>%
  group_by(grappe, menage) %>%
  mutate(
    modalite_majoritaire = {
      freq <- table(s02q03)
      if (length(freq) > 0) names(freq)[which.max(freq)] else NA_character_
    },
    s02q03 = ifelse(is.na(s02q03), modalite_majoritaire, s02q03)
  ) %>%
  ungroup() %>%
  select(-modalite_majoritaire)

# Variable s02q05 - École non formelle

data1$s02q05 <- as.character(data1$s02q05)

data1 <- data1 %>%
  group_by(grappe, menage) %>%
  mutate(
    modalite_majoritaire = {
      freq <- table(s02q05)
      if (length(freq) > 0) names(freq)[which.max(freq)] else NA_character_
    },
    s02q05 = ifelse(is.na(s02q05), modalite_majoritaire, s02q05)
  ) %>%
  ungroup() %>%
  select(-modalite_majoritaire)

# ------------------------------------------------------------------
# 3. Création de l'indicatrice de scolarisation
# ------------------------------------------------------------------

data1 <- data1 %>%
  mutate(indicatrice_ecole = if_else(s02q05 == "1" | s02q03 == "1", 1, 0))

# ------------------------------------------------------------------
# 4. Imputation des valeurs manquantes de l’indicatrice
# ------------------------------------------------------------------

modalite_majoritaire_par_menage <- data1 %>%
  group_by(grappe, menage) %>%
  summarise(
    modalite_majoritaire = {
      vec <- indicatrice_ecole[!is.na(indicatrice_ecole)]
      if (length(vec) == 0) NA else names(sort(table(vec), decreasing = TRUE))[1]
    },
    .groups = "drop"
  )

data1 <- data1 %>%
  left_join(modalite_majoritaire_par_menage, by = c("grappe", "menage")) %>%
  mutate(indicatrice_ecole = ifelse(is.na(indicatrice_ecole), modalite_majoritaire, indicatrice_ecole)) %>%
  select(-modalite_majoritaire)

# Suppression des observations restantes manquantes
data1 <- data1 %>%
  filter(!is.na(indicatrice_ecole))

# ------------------------------------------------------------------
# 5. Agrégation au niveau des ménages
# ------------------------------------------------------------------

data_menage <- data1 %>%
  group_by(grappe, menage) %>%
  summarise(
    nb_individus = n(),
    nb_individus_etudes = sum(indicatrice_ecole == 1, na.rm = TRUE),
    .groups = "drop"
  )

# ------------------------------------------------------------------
# 6. Sauvegarde de la base finale
# ------------------------------------------------------------------

write_dta(data_menage, "Bases de données/data_menage.dta")

# ------------------------------------------------------------------
# Fin du script 01
# ------------------------------------------------------------------


# ----------------------------------------------------------------------------------------------------
# SCRIPT 02 : Traitement des données sur les dépenses en santé - EHCVM 2018-2019
# ----------------------------------------------------------------------------------------------------


# Chargement des packages

library(haven)
library(tidyr)
library(dplyr)

# Lecture des données depuis le dossier "Base de données"

data2 <- read_dta("Bases de données/s03_me_SEN2018.dta")
View(data2)

# Création de la variable des dépenses annuelles de santé hors assurance

data2 <- data2 %>%
  mutate(depense_sante_hors_assurance =
           replace_na(s03q13, 0) * 4 +
           replace_na(s03q14, 0) * 4 +
           replace_na(s03q15, 0) * 4 +
           replace_na(s03q16, 0) * 4 +
           replace_na(s03q17, 0) * 4 +
           replace_na(s03q18, 0) * 4 +
           replace_na(s03q24, 0) +
           replace_na(s03q26, 0) +
           replace_na(s03q27, 0) +
           replace_na(s03q29, 0) +
           replace_na(s03q30, 0) +
           replace_na(s03q31, 0))

# Création de la variable des dépenses avec assurance incluse

data2 <- data2 %>%
  mutate(depense_sante_avec_assurance = depense_sante_hors_assurance - 
           (replace_na(s03q33, 0) * depense_sante_hors_assurance) / 100)

# Agrégation des dépenses au niveau des ménages

depenses_menage <- data2 %>%
  group_by(grappe, menage) %>%
  summarise(depense_sante_menage = sum(depense_sante_avec_assurance, na.rm = TRUE), .groups = "drop")

View(depenses_menage)

# Enregistrement du fichier au format .dta dans le dossier de travail

write_dta(depenses_menage, "Bases de données/depenses_menage.dta")


# ------------------------------------------------------------------
# Fin du script 02
# ------------------------------------------------------------------



# ----------------------------------------------------------------------------------------
# SCRIPT 03 : Traitement des données sur les revenus issus de l'emploi - EHCVM 2018-2019
# ----------------------------------------------------------------------------------------

# Chargement des packages nécessaires

library(haven)
library(dplyr)
library(tidyr)

# Importation des données depuis le dossier "Base de données"

data3 <- read_dta("Bases de données/s04_me_SEN2018.dta")
View(data3)

# Vérification de la taille du dataframe

dim(data3)  # 66120 observations et 93 variables

# Création des variables de conversion des unités en fréquence annuelle

data3 <- data3 %>%
  mutate(
    unite1 = case_when(s04q43_unite == 1 ~ 52,
                       s04q43_unite == 2 ~ 12,
                       s04q43_unite == 3 ~ 4,
                       s04q43_unite == 4 ~ 1),
    unite2 = case_when(s04q45_unite == 1 ~ 52,
                       s04q45_unite == 2 ~ 12,
                       s04q45_unite == 3 ~ 4,
                       s04q45_unite == 4 ~ 1),
    unite3 = case_when(s04q47_unite == 1 ~ 52,
                       s04q47_unite == 2 ~ 12,
                       s04q47_unite == 3 ~ 4,
                       s04q47_unite == 4 ~ 1),
    unite4 = case_when(s04q49_unite == 1 ~ 52,
                       s04q49_unite == 2 ~ 12,
                       s04q49_unite == 3 ~ 4,
                       s04q49_unite == 4 ~ 1),
    unite5 = case_when(s04q58_unite == 1 ~ 52,
                       s04q58_unite == 2 ~ 12,
                       s04q58_unite == 3 ~ 4,
                       s04q58_unite == 4 ~ 1),
    unite6 = case_when(s04q60_unite == 1 ~ 52,
                       s04q60_unite == 2 ~ 12,
                       s04q60_unite == 3 ~ 4,
                       s04q60_unite == 4 ~ 1),
    unite7 = case_when(s04q62_unite == 1 ~ 52,
                       s04q62_unite == 2 ~ 12,
                       s04q62_unite == 3 ~ 4,
                       s04q62_unite == 4 ~ 1),
    unite8 = case_when(s04q64_unite == 1 ~ 52,
                       s04q64_unite == 2 ~ 12,
                       s04q64_unite == 3 ~ 4,
                       s04q64_unite == 4 ~ 1)
  )

# Calcul du revenu annuel issu de l'emploi

data3 <- data3 %>%
  mutate(
    revenu_emploi = replace_na(unite1, 0) * replace_na(s04q43, 0) +
      replace_na(unite2, 0) * replace_na(s04q45, 0) +
      replace_na(unite3, 0) * replace_na(s04q47, 0) +
      replace_na(unite4, 0) * replace_na(s04q49, 0) +
      replace_na(unite5, 0) * replace_na(s04q58, 0) +
      replace_na(unite6, 0) * replace_na(s04q60, 0) +
      replace_na(unite7, 0) * replace_na(s04q62, 0) +
      replace_na(unite8, 0) * replace_na(s04q64, 0)
  )

# Affichage des lignes pour contrôle

View(data3[, c("grappe", "menage", "revenu_emploi")])

# ------------------------------------------------------------------
# Fin du script 03
# ------------------------------------------------------------------



# ---------------------------------------------------------------------------------------------------------------
# SCRIPT 04 : Traitement des données sur les revenus non issus de l'emploi - EHCVM 2018-2019
# ---------------------------------------------------------------------------------------------------------------

# Chargement des packages nécessaires

library(haven)
library(dplyr)

# Importation des données depuis le dossier "Base de données"

data4 <- read_dta("Bases de données/s05_me_SEN2018.dta")
View(data4)

# Vérification de la taille du dataframe

dim(data4)  # 66120 observations et 19 variables

# Calcul du revenu annuel non issu de l'emploi (pensions, aides, etc.)

data4 <- data4 %>%
  mutate(
    revenu_non_emploi = rowSums(across(c(s05q02, s05q04, s05q06, s05q08, s05q10, s05q12, s05q14)), na.rm = TRUE)
  )

View(data4[, "revenu_non_emploi"])

# Création de la base des revenus annuels individuels (fusion revenus emploi + non emploi)

revenu_annuel_individuel <- data3 %>%
  select(vague, grappe, menage, s01q00a, revenu_emploi) %>%
  distinct() %>%
  full_join(
    data4 %>%
      select(vague, grappe, menage, s01q00a, revenu_non_emploi) %>%
      distinct(),
    by = c("vague", "grappe", "menage", "s01q00a")
  )

View(revenu_annuel_individuel)

# Agrégation des revenus au niveau du ménage

revenu_annuel_menage <- revenu_annuel_individuel %>%
  select(-s01q00a) %>%
  group_by(vague, grappe, menage) %>%
  summarise(
    revenu_emploi_total = sum(revenu_emploi, na.rm = TRUE),
    revenu_non_emploi_total = sum(revenu_non_emploi, na.rm = TRUE),
    .groups = "drop"
  )

View(revenu_annuel_menage)


# ------------------------------------------------------------------
# Fin du script 04
# ------------------------------------------------------------------


# ----------------------------------------------------------------------------------------
# SCRIPT 05 : Traitement des données sur les transferts - EHCVM 2018-2019
# ----------------------------------------------------------------------------------------

# Chargement du package

library(haven)

# Transferts reçus

data5 <- read_dta("Bases de données/s13a_2_me_sen2018.dta")
View(data5)

# Taille du dataframe

dim(data5) # 8403 observations et 19 variables

# Création des variables intermédiaires

data5$frequence <- ifelse(data5$s13aq17b == 1, 12,
                          ifelse(data5$s13aq17b == 2, 4,
                                 ifelse(data5$s13aq17b == 3, 2,
                                        ifelse(data5$s13aq17b == 4, 1,
                                               ifelse(data5$s13aq17b == 5, 1, NA))))) # Transfert irrégulier

# Transfert total

library(dplyr)

data5 <- data5 %>%
  mutate(Transfert_total = coalesce(frequence, 0) * coalesce(s13aq17a, 0))

# Transfert total par ménage

data5 <- data5 %>%
  group_by(vague, grappe, menage) %>%
  mutate(transfert_total_menage = sum(Transfert_total, na.rm = TRUE)) %>%
  ungroup()

# Insertion de la variable 'transfert_total_menage' dans la base 'revenu_annuel_menage'

# Étape 1 : Créer une table avec les transferts par ménage (en ne gardant que la première occurrence)

transferts_menage <- data5 %>%
  group_by(vague, grappe, menage) %>%
  summarise(transfert_total_menage = first(transfert_total_menage), .groups = "drop")

# Étape 2 : Fusionner avec revenu_annuel_menage

revenu_annuel_menage <- revenu_annuel_menage %>%
  left_join(transferts_menage, by = c("vague", "grappe", "menage")) %>%
  mutate(transfert_total_menage = coalesce(transfert_total_menage, 0))

View(revenu_annuel_menage)


# Calcul du revenu total au cours des 12 derniers mois

revenu_annuel_menage <- revenu_annuel_menage %>%
  mutate(
    revenu_total = coalesce(revenu_emploi_total, 0) +
      coalesce(revenu_non_emploi_total, 0) +
      coalesce(transfert_total_menage, 0)
  )

# Part des tranferts dans le revenu total

revenu_annuel_menage <- revenu_annuel_menage %>%
  mutate(part_transferts_dans_revenu_total = round(100 * transfert_total_menage / 
                                                     revenu_total, 2))

sum(is.na(revenu_annuel_menage$part_transferts_dans_revenu_total)) # 1530 ménages sans aucun revenu.


# Renommer la variable 'part_transferts_dans_revenu_total' pour la rendre compatible avec Stata

revenu_annuel_menage <- revenu_annuel_menage %>%
  rename(
    part_transferts_revenu_total = part_transferts_dans_revenu_total
  )

# Exporter le data frame en format .dta

write_dta(revenu_annuel_menage, "Bases de données/revenu_12_derniers_mois_menage_EHCVM.dta")


# ------------------------------------------------------------------
# Fin du script 05
# ------------------------------------------------------------------


# ----------------------------------------------------------------------------------------
# SCRIPT 06 : Analyse - EHCVM 2018-2019
# ----------------------------------------------------------------------------------------


# Installation des packages nécessaires

install.packages("haven")
install.packages("dplyr")
install.packages("skimr")
install.packages("psych")
install.packages("moments")
install.packages("tidyr")
install.packages("ggplot2")
install.packages("ggpubr")

# Chargement du package

library(haven)

data6 <- read_dta("Bases de données/revenu_12_derniers_mois_menage_EHCVM.dta")
data7 <- read_dta("Bases de données/data_menage.dta")
data8 <- read_dta("Bases de données/depenses_menage.dta")

View(data6)
View(data7)
View(data8)
View(data_menage_final)

# Fusion successive des trois bases

data_menage_final <- data6 %>%
  inner_join(data7, by = c("grappe", "menage")) %>%
  inner_join(data8, by = c("grappe", "menage"))

data_menage_final <- data_menage_final %>%
  mutate(ratio_etude = 100* nb_individus_etudes / nb_individus)

# Relation entre transferts reçus et éducation

# Visualisation

library(ggplot2)
library(ggpubr)

# Modèle de régression

modele <- lm(transfert_total_menage ~ ratio_etude, data = data_menage_final)

# Extraire les paramètres

a <- round(coef(modele)[1], 2)
b <- round(coef(modele)[2], 2)
r2 <- round(summary(modele)$r.squared, 3)
p <- round(summary(modele)$coefficients[2, 4], 3)

# Créer l'équation formatée en texte 

eq_text <- paste0("y = ", b, "x + ", a,
                  "   |   R² = ", r2,
                  "   |   p = ", p)

# Graphique

ggplot(data_menage_final, aes(x = ratio_etude, y = transfert_total_menage)) +
  geom_point(alpha = 0.6) +
  geom_smooth(method = "lm", se = TRUE, color = "blue") +
  annotate("text", 
           x = 0.1, 
           y = 9500000, 
           label = eq_text, 
           size = 4, 
           hjust = 0, 
           color = "black") +
  labs(
    x = "Ratio d'étudiants dans le ménage (en %)",
    y = "Transferts reçus",
    title = "Relation entre éducation et transferts reçus"
  ) +
  coord_cartesian(ylim = c(0, 10000000))



# Définition des groupes de ménages selon ratio_etude

data_menage_final <- data_menage_final %>%
  mutate(groupe_ratio = cut(ratio_etude,
                            breaks = c(0, 25, 50, 75, 100),
                            labels = c("Faible", "Modéré", "Élevé", "Très élevé"),
                            include.lowest = TRUE,
                            right = FALSE))


# Filtrer les NA avant de résumer

df_transferts_groupes <- data_menage_final %>%
  filter(!is.na(groupe_ratio), !is.na(transfert_total_menage)) %>%
  group_by(groupe_ratio) %>%
  summarise(transferts_moyens = mean(transfert_total_menage), .groups = "drop")


# Visualisations

# Diagramme en barres des moyennes par groupe

ggplot(df_transferts_groupes, aes(x = groupe_ratio, y = transferts_moyens, fill = groupe_ratio)) +
  geom_bar(stat = "identity", width = 0.6) +
  geom_text(aes(label = round(transferts_moyens, 1)), vjust = -0.5, size = 4) +
  scale_fill_manual(values = c("Faible" = "#A6ACAF", "Modéré" = "#85929E",
                               "Élevé" = "#5D6D7E", "Très élevé" = "#34495E")) +
  labs(title = "Transferts moyens par groupe de ratio d'études",
       x = "Groupe de ratio d'études",
       y = "Montant moyen des transferts (en FCFA)") +
  theme_minimal() +
  theme(legend.position = "none")


# Boxplot par groupe

ggplot(data_menage_final, aes(x = groupe_ratio, y = transfert_total_menage, fill = groupe_ratio)) +
  geom_boxplot(outlier.color = "red", outlier.size = 1.5) +
  scale_fill_manual(values = c("Faible" = "#A6ACAF", "Modéré" = "#85929E",
                               "Élevé" = "#5D6D7E", "Très élevé" = "#34495E")) +
  labs(title = "Distribution des transferts par groupe de ratio d'études",
       x = "Groupe de ratio d'études",
       y = "Transferts reçus (en FCFA)") +
  theme_minimal() +
  theme(legend.position = "none")


# Relation entre transferts reçus et dépenses en santé

# Filtrer les dépenses de santé positives ou nulles

data_sante <- data_menage_final %>%
  filter(depense_sante_menage >= 0)


# Modèle de régression

modele_sante <- lm(depense_sante_menage ~ transfert_total_menage, data = data_sante)

# Extraire les paramètres

a_sante <- round(coef(modele_sante)[1], 2)
b_sante <- round(coef(modele_sante)[2], 2)
r2_sante <- round(summary(modele_sante)$r.squared, 3)
p_sante <- formatC(summary(modele_sante)$coefficients[2, 4], format = "f", digits = 4)

# Texte de l’équation

eq_text_sante <- paste0("y = ", b_sante, "x + ", a_sante,
                        "   |   R² = ", r2_sante,
                        "   |   p = ", p_sante)

# Visualisation

ggplot(data_sante, aes(x = transfert_total_menage, y = depense_sante_menage)) +
  geom_point(alpha = 0.6) +
  geom_smooth(method = "lm", se = TRUE, color = "blue") +
  annotate("text", 
           x = 500000, 
           y = 3900000,  # Texte bien en haut
           label = eq_text_sante, 
           size = 5, 
           hjust = 0, 
           color = "black") +
  labs(
    x = "Transferts reçus par le ménage (en FCFA)",
    y = "Dépenses de santé du ménage (en FCFA)",
    title = "Relation entre transferts reçus et dépenses de santé"
  ) +
  coord_cartesian(xlim = c(0, 10000000), ylim = c(0, 4000000)) +
  theme_minimal()

# Relation entre transferts reçus et revenu total non issu du rendement agricole (emploi,non emploi et transfert)

summary_stats_filtre <- data_menage_final %>%
  filter(!is.na(part_transferts_revenu_total)) %>%
  summarise(
    Effectif = n(),
    Moyenne = mean(part_transferts_revenu_total),
    Médiane = median(part_transferts_revenu_total),
    Écart_type = sd(part_transferts_revenu_total),
    Min = min(part_transferts_revenu_total),
    Max = max(part_transferts_revenu_total),
    Q1 = quantile(part_transferts_revenu_total, 0.25),
    Q3 = quantile(part_transferts_revenu_total, 0.75)
  )

View(summary_stats_filtre)


# Diagramme en barres

data_menage_final %>%
  filter(!is.na(part_transferts_revenu_total)) %>%
  ggplot(aes(x = part_transferts_revenu_total)) +
  geom_histogram(binwidth = 5, fill = "steelblue", color = "white", aes(y = after_stat(count / sum(count)))) +
  labs(title = "Histogramme des parts de transferts dans le revenu total",
       x = "Part des transferts dans le revenu total (%)",
       y = "Proportion") +
  scale_y_continuous(labels = scales::percent_format()) +
  theme_minimal()


# Histogramme avec pourcentages

data_menage_final %>%
  filter(!is.na(part_transferts_revenu_total)) %>%
  ggplot(aes(x = part_transferts_revenu_total)) +
  geom_histogram(
    aes(y = after_stat(count / sum(count))),
    binwidth = 5,
    fill = "steelblue",
    color = "white",
    alpha = 0.8
  ) +
  stat_bin(
    aes(y = after_stat(count / sum(count)), 
        label = round(after_stat(count / sum(count)) * 100, 1)),
    binwidth = 5,
    geom = "text",
    vjust = -0.5,
    size = 2.5
  ) +
  labs(
    title = "Histogramme des parts de transferts dans le revenu total",
    x = "Part des transferts dans le revenu total (%)",
    y = "Proportion"
  ) +
  theme_minimal()



# Corrélation entre transferts et revenus totaux

# Filtrer les données valides s'il y en a (revenu total non manquant et >= 0)

data_revenu <- data_menage_final %>%
  filter(!is.na(revenu_total), revenu_total >= 0)


# Modèle de régression

modele_revenu <- lm(revenu_total ~ transfert_total_menage, data = data_revenu)

# Extraire les paramètres

a_rev <- round(coef(modele_revenu)[1], 2)
b_rev <- round(coef(modele_revenu)[2], 2)
r2_rev <- round(summary(modele_revenu)$r.squared, 3)
p_rev <- formatC(summary(modele_revenu)$coefficients[2, 4], format = "f", digits = 4)


# Texte de l’équation

eq_text_rev <- paste0("y = ", b_rev, "x + ", a_rev,
                      "   |   R² = ", r2_rev,
                      "   |   p = ", p_rev)



# Visualisation

ggplot(data_revenu, aes(x = transfert_total_menage, y = revenu_total)) +
  geom_point(alpha = 0.6) +
  geom_smooth(method = "lm", se = TRUE, color = "blue") +
  annotate("text", 
           x = 500000, 
           y = max(data_revenu$revenu_total, na.rm = TRUE) * 0.95,  # Texte haut
           label = eq_text_rev, 
           size = 5, 
           hjust = 0, 
           color = "black") +
  labs(
    x = "Transferts reçus par le ménage (en FCFA)",
    y = "Revenu total du ménage (en FCFA)",
    title = "Relation entre transferts reçus et revenu total"
  ) +
  coord_cartesian(xlim = c(0, 10000000)) +
  theme_minimal()


# ------------------------------------------------------------------
# Fin du script 05
# ------------------------------------------------------------------
